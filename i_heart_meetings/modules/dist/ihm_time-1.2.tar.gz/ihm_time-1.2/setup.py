from setuptools import setup

setup(
    name='ihm_time',
    version='1.2',
    description='Time conversion functions',
    author='Drew Sullivan',
    author_email='drew.sullivan.dma@gmail.com',
    url='iheartmeetings.com',
    py_modules=['ihm_time'],
)
